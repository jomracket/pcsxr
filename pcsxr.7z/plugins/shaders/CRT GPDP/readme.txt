For use with a window resolution of 1280x960 only.

Increasing the internal resolution in tandem with this shader requires setting the shader level to the following:

Native - Shader Level 1
High - Shader Level 2
Very High - Shader Level 4